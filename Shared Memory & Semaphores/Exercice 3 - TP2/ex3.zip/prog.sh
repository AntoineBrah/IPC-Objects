g++ -c prog.c ; g++ prog.o -o prog ; ./prog $1
